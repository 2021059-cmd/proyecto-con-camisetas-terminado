const express = require('express');
const router = express.Router();
const auth = require('../middleware/authMiddleware');
const { nanoid } = require('nanoid');
router.post('/', auth, async (req,res)=>{
  const db = req.db; await db.read();
  const { items, total } = req.body;
  // validar stock
  for(const it of items){
    const p = db.data.products.find(x=>x.id===it.productId);
    if(!p) return res.status(400).json({message:`Producto ${it.productId} no existe`});
    if(p.stock < it.qty) return res.status(400).json({message:`Stock insuficiente para ${p.title}`});
  }
  // descontar stock
  for(const it of items){
    const p = db.data.products.find(x=>x.id===it.productId);
    p.stock -= it.qty;
  }
  const order = { id: 'o_'+nanoid(6), userId: req.user.id, items, total, createdAt: new Date().toISOString(), status:'pending' };
  db.data.orders.push(order); await db.write();
  res.json(order);
});
router.get('/my', auth, async (req,res)=>{ const db=req.db; await db.read(); const orders = db.data.orders.filter(o=>o.userId===req.user.id); res.json(orders); });
module.exports = router;
