const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { nanoid } = require('nanoid');
router.post('/register', async (req,res)=>{
  const db = req.db; await db.read();
  const { name, email, password } = req.body;
  if(!email||!password) return res.status(400).json({message:'Faltan datos'});
  if(db.data.users.find(u=>u.email===email)) return res.status(400).json({message:'Usuario ya existe'});
  const hash = await bcrypt.hash(password,10);
  const user = { id: 'u_'+nanoid(6), name, email, passwordHash: hash, role:'user' };
  db.data.users.push(user); await db.write();
  const token = jwt.sign({ id:user.id, email:user.email, role:user.role }, process.env.JWT_SECRET || 'dev_secret');
  res.json({ token, user: { id:user.id, name:user.name, email:user.email } });
});
router.post('/login', async (req,res)=>{
  const db = req.db; await db.read();
  const { email, password } = req.body;
  const user = db.data.users.find(u=>u.email===email);
  if(!user) return res.status(400).json({message:'Credenciales inválidas'});
  const ok = await bcrypt.compare(password, user.passwordHash);
  if(!ok) return res.status(400).json({message:'Credenciales inválidas'});
  const token = jwt.sign({ id:user.id, email:user.email, role:user.role }, process.env.JWT_SECRET || 'dev_secret');
  res.json({ token, user: { id:user.id, name:user.name, email:user.email } });
});
module.exports = router;
