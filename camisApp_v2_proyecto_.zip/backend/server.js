require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { Low, JSONFile } = require('lowdb');
const path = require('path');
const app = express();
app.use(cors());
app.use(express.json({ limit: '5mb' }));
const file = path.join(__dirname, 'db', 'db.json');
const adapter = new JSONFile(file);
const db = new Low(adapter);
async function initDB(){ await db.read(); db.data = db.data || { users:[], products:[], orders:[] }; await db.write(); }
initDB();
app.use((req,res,next)=>{ req.db = db; next(); });
app.use('/api/auth', require('./routes/auth'));
app.use('/api/products', require('./routes/products'));
app.use('/api/orders', require('./routes/orders'));
const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> console.log(`Backend running on port ${PORT}`));
