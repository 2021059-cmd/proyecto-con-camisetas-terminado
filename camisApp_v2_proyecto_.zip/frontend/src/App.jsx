import React from 'react'
import { Outlet, Link } from 'react-router-dom'
import './styles/main.css'
export default function App(){
  return (
    <div>
      <header className="topbar">
        <Link to="/">camisApp</Link>
        <nav>
          <Link to="/cart">Carrito</Link>
          <Link to="/login">Login</Link>
          <Link to="/admin">Admin</Link>
        </nav>
      </header>
      <main className="container"><Outlet/></main>
    </div>
  )
}
