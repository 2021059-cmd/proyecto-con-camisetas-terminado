import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import App from './App'
import Home from './pages/Home'
import ProductPage from './pages/ProductPage'
import CartPage from './pages/CartPage'
import Login from './pages/Login'
import Admin from './pages/Admin'
import './styles/main.css'
createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<App/>}>
          <Route index element={<Home/>} />
          <Route path='product/:id' element={<ProductPage/>} />
          <Route path='cart' element={<CartPage/>} />
          <Route path='login' element={<Login/>} />
          <Route path='admin' element={<Admin/>} />
        </Route>
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
)
