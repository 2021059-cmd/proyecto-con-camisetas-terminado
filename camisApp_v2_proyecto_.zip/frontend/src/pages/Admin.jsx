import React, {useState} from 'react';
import API, { setToken } from '../api';
export default function Admin(){
  const [form,setForm]=useState({ title:'', description:'', price:0, stock:0, sizes:[], colors:[], image:'' });
  const submit=async e=>{ e.preventDefault(); const token=localStorage.getItem('token'); if(!token){ alert('Login admin'); return;} setToken(token); try{ const r = await API.post('/products', form); alert('Creado '+r.data.id); }catch(err){ alert(err.response?.data?.message||err.message)} }
  return (
    <div>
      <h1>Admin - crear producto</h1>
      <form onSubmit={submit}>
        <input placeholder="Título" value={form.title} onChange={e=>setForm({...form, title:e.target.value})}/>
        <input placeholder="Descripción" value={form.description} onChange={e=>setForm({...form, description:e.target.value})}/>
        <input type="number" placeholder="Precio" value={form.price} onChange={e=>setForm({...form, price:Number(e.target.value)})}/>
        <input type="number" placeholder="Stock" value={form.stock} onChange={e=>setForm({...form, stock:Number(e.target.value)})}/>
        <input placeholder="Tallas (coma)" value={form.sizes} onChange={e=>setForm({...form, sizes: e.target.value.split(',')})}/>
        <input placeholder="Colores (coma)" value={form.colors} onChange={e=>setForm({...form, colors: e.target.value.split(',')})}/>
        <input placeholder="URL imagen" value={form.image} onChange={e=>setForm({...form, image:e.target.value})}/>
        <button type="submit">Crear producto</button>
      </form>
    </div>
  )
}
