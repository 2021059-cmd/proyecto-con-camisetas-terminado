import React, {useEffect,useState} from 'react';
import API from '../api';
import { Link } from 'react-router-dom';
export default function Home(){
  const [products,setProducts]=useState([]);
  useEffect(()=>{ API.get('/products').then(r=>setProducts(r.data)).catch(()=>{}); },[]);
  return (
    <div>
      <h1>Catálogo</h1>
      <div className="grid">
        {products.map(p=>(
          <div key={p.id} className="card">
            <img src={p.image||''} alt={p.title} className="thumb"/>
            <h3>{p.title}</h3>
            <p>{p.description}</p>
            <p>₡{p.price} - Stock: {p.stock}</p>
            <Link to={`/product/${p.id}`}>Ver</Link>
          </div>
        ))}
      </div>
    </div>
  )
}
