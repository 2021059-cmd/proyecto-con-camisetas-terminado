import React, {useState} from 'react';
import API, { setToken } from '../api';
export default function CartPage(){ 
  const [cart,setCart] = useState(JSON.parse(localStorage.getItem('cart')||'[]'));
  const total = cart.reduce((s,i)=>s+i.price*i.qty,0);
  const clear = ()=>{ localStorage.removeItem('cart'); setCart([]); }
  const checkout = async ()=>{
    const token = localStorage.getItem('token');
    if(!token){ alert('Logueate para comprar'); return; }
    setToken(token);
    try{
      const r = await API.post('/orders', { items: cart.map(i=>({ productId:i.productId, qty:i.qty })), total });
      alert('Orden creada: ' + r.data.id);
      clear();
    }catch(err){ alert(err.response?.data?.message || err.message) }
  }
  return (
    <div>
      <h1>Carrito</h1>
      {cart.length===0 ? <p>Carrito vacío</p> : (
        <div>
          <ul>{cart.map((it,idx)=>(<li key={idx}>{it.title} x{it.qty} - ₡{it.price*it.qty}</li>))}</ul>
          <p>Total: ₡{total}</p>
          <button onClick={checkout}>Pagar</button>
          <button onClick={clear}>Vaciar</button>
        </div>
      )}
    </div>
  )
}
