import React, {useEffect,useState} from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import API from '../api';
export default function ProductPage(){
  const { id } = useParams(); const [p,setP]=useState(null); const [qty,setQty]=useState(1); const nav = useNavigate();
  useEffect(()=>{ API.get(`/products/${id}`).then(r=>setP(r.data)).catch(()=>{}); },[id]);
  const add = ()=>{
    const cart = JSON.parse(localStorage.getItem('cart')||'[]');
    cart.push({ productId: p.id, title:p.title, price:p.price, qty });
    localStorage.setItem('cart', JSON.stringify(cart));
    nav('/cart');
  }
  if(!p) return <div>Cargando...</div>
  return (
    <div>
      <h2>{p.title}</h2>
      <img src={p.image||''} alt={p.title} style={{maxWidth:240}}/>
      <p>{p.description}</p>
      <p>₡{p.price} - Stock: {p.stock}</p>
      <label>Cantidad: <input type="number" min="1" max={p.stock} value={qty} onChange={e=>setQty(Number(e.target.value))}/></label>
      <button onClick={add}>Agregar al carrito</button>
    </div>
  )
}
