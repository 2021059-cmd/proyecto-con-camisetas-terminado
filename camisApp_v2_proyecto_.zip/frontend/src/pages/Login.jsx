import React, {useState} from 'react';
import API, { setToken } from '../api';
export default function Login(){
  const [email,setEmail]=useState(''); const [pass,setPass]=useState('');
  const login = async (e)=>{ e.preventDefault(); try{ const r = await API.post('/auth/login', { email, password: pass }); localStorage.setItem('token', r.data.token); setToken(r.data.token); alert('Logueado'); }catch(err){ alert(err.response?.data?.message || err.message) } }
  const reg = async (e)=>{ e.preventDefault(); try{ const r = await API.post('/auth/register', { name:'Alumno', email, password: pass }); localStorage.setItem('token', r.data.token); setToken(r.data.token); alert('Registrado'); }catch(err){ alert(err.response?.data?.message || err.message) } }
  return (
    <div>
      <h1>Login / Register</h1>
      <form onSubmit={login}>
        <input placeholder="email" value={email} onChange={e=>setEmail(e.target.value)}/>
        <input placeholder="password" type="password" value={pass} onChange={e=>setPass(e.target.value)}/>
        <button type="submit">Login</button>
        <button onClick={reg} style={{marginLeft:8}}>Register</button>
      </form>
    </div>
  )
}
