# camisApp - Proyecto completo (Entrega)

**Alumno:** Mario Vargas Montes


## Instrucciones rápidas


1. Backend: copiar `.env.example` a `.env` y poner `JWT_SECRET`.

2. Desde `backend/` ejecutar `npm install` y `npm run dev`.

3. Frontend: desde `frontend/` ejecutar `npm install` y `npm run dev`.


## Notas


- Incluye autenticación (register/login), carrito local y validación de stock al crear órdenes.

- Productos con campo `image` (usa URLs públicas o sube imágenes en `frontend/public/img`).

- Proyecto listo para subir a GitHub. Nombre de entrega: **Proyecto Camisetas - Mario Vargas Montes**.
